QSP UPS Service Manager - User Connect

Purpose
-------
A separate Windows launcher for new UPS Service Manager users. It checks/opens Tailscale, provides the new-user registration form, submits the registration to the existing UPS Service Manager server, and opens the existing login page.

Server
------
http://ups-service-manager.tail62d8a1.ts.net:8765/

Important
---------
- The launcher does not store the user's password.
- Tailscale authentication is handled by Tailscale itself.
- Existing UPS Service Manager files are not modified by this package.
- This development build uses Python 3.11. A packaged EXE can be produced later on a Windows PC with PyInstaller.

User flow
---------
1. Start QSP_UPS_User_Connect.py (or Start_User_Connect.bat).
2. Click Check / Start Tailscale.
3. Sign in to Tailscale with the user's own account and make sure the shared ups-service-manager machine is visible.
4. Fill Email, Username, Password and Confirm Password.
5. Click REGISTER & OPEN LOGIN.
6. Admin approves the signup in UPS Service Manager.
7. User logs in through the opened UPS Service Manager page.


V1.1 Auto-Python setup:
Run Install_User_Connect.bat. If Python 3.11 is missing, the setup downloads the official Python 3.11.9 Windows 64-bit installer from python.org and installs it silently for the current Windows user, then starts the app. Internet access is required for the first installation.
