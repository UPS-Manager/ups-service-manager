@echo off
setlocal
cd /d "%~dp0"
py -3.11 QSP_UPS_User_Connect.py
if errorlevel 1 (
  echo.
  echo Could not start User Connect. Python 3.11 is required for this development build.
  pause
)
