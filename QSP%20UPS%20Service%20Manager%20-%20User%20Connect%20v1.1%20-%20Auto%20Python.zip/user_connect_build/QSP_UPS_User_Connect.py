import json
import os
import shutil
import subprocess
import threading
import time
import urllib.request
import urllib.error
import webbrowser
import tkinter as tk
from tkinter import ttk, messagebox

SERVER_URL = "http://ups-service-manager.tail62d8a1.ts.net:8765"
APP_TITLE = "QSP UPS Service Manager - User Connect"


def find_tailscale():
    candidates = [
        shutil.which("tailscale.exe"),
        shutil.which("tailscale"),
        os.path.join(os.environ.get("ProgramFiles", r"C:\\Program Files"), "Tailscale", "tailscale.exe"),
        os.path.join(os.environ.get("ProgramFiles(x86)", r"C:\\Program Files (x86)"), "Tailscale", "tailscale.exe"),
    ]
    return next((p for p in candidates if p and os.path.exists(p)), None)


def run_cmd(args, timeout=15):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return 99, str(e)


class App:
    def __init__(self, root):
        self.root = root
        root.title(APP_TITLE)
        root.geometry("720x650")
        root.minsize(650, 600)
        root.configure(bg="#eef3f7")
        self.ts_path = None
        self.connected = False

        style = ttk.Style()
        try: style.theme_use('clam')
        except Exception: pass
        style.configure('Title.TLabel', font=('Segoe UI', 20, 'bold'), foreground='#17324d', background='#ffffff')
        style.configure('Sub.TLabel', font=('Segoe UI', 10), foreground='#5b6773', background='#ffffff')
        style.configure('Head.TLabel', font=('Segoe UI', 11, 'bold'), foreground='#17324d', background='#ffffff')
        style.configure('TLabel', font=('Segoe UI', 10), background='#ffffff')
        style.configure('Primary.TButton', font=('Segoe UI', 10, 'bold'), padding=10)

        outer = tk.Frame(root, bg='#eef3f7')
        outer.pack(fill='both', expand=True, padx=24, pady=24)
        card = tk.Frame(outer, bg='white', highlightthickness=1, highlightbackground='#d7e0e8')
        card.pack(fill='both', expand=True)

        header = tk.Frame(card, bg='white')
        header.pack(fill='x', padx=28, pady=(24, 8))
        logo_path = os.path.join(os.path.dirname(__file__), 'assets', 'QSP_LOGO.png')
        if os.path.exists(logo_path):
            try:
                self.logo = tk.PhotoImage(file=logo_path)
                # Keep logo at a reasonable size without external PIL dependency.
                if self.logo.width() > 170:
                    factor = max(1, self.logo.width() // 170)
                    self.logo = self.logo.subsample(factor, factor)
                tk.Label(header, image=self.logo, bg='white').pack(side='left', padx=(0,14))
            except Exception: pass
        texts = tk.Frame(header, bg='white')
        texts.pack(side='left', fill='x', expand=True)
        ttk.Label(texts, text='UPS Service Manager', style='Title.TLabel').pack(anchor='w')
        ttk.Label(texts, text='Secure User Connection & Registration', style='Sub.TLabel').pack(anchor='w', pady=(3,0))

        ttk.Separator(card).pack(fill='x', padx=28, pady=12)
        body = tk.Frame(card, bg='white')
        body.pack(fill='both', expand=True, padx=28, pady=4)

        ttk.Label(body, text='1. Secure connection', style='Head.TLabel').pack(anchor='w', pady=(0,8))
        self.status = tk.StringVar(value='Checking Tailscale...')
        self.status_label = tk.Label(body, textvariable=self.status, bg='#f8fafc', fg='#374151', anchor='w', padx=12, pady=9, relief='solid', bd=1)
        self.status_label.pack(fill='x')
        btns = tk.Frame(body, bg='white'); btns.pack(fill='x', pady=8)
        ttk.Button(btns, text='Check / Start Tailscale', command=self.check_tailscale).pack(side='left')
        ttk.Button(btns, text='Open Tailscale', command=self.open_tailscale).pack(side='left', padx=8)

        ttk.Label(body, text='2. New user registration', style='Head.TLabel').pack(anchor='w', pady=(14,8))
        form = tk.Frame(body, bg='white'); form.pack(fill='x')
        self.email = tk.StringVar(); self.username = tk.StringVar(); self.password = tk.StringVar(); self.confirm = tk.StringVar()
        for i,(label,var,show) in enumerate([
            ('Email',self.email,''),('Username',self.username,''),('Password',self.password,'•'),('Confirm Password',self.confirm,'•')
        ]):
            tk.Label(form,text=label,bg='white',fg='#4b5563',font=('Segoe UI',9,'bold')).grid(row=i,column=0,sticky='w',pady=6)
            e=tk.Entry(form,textvariable=var,show=show,font=('Segoe UI',10),relief='solid',bd=1)
            e.grid(row=i,column=1,sticky='ew',padx=(14,0),ipady=7)
        form.grid_columnconfigure(1,weight=1)

        self.result = tk.StringVar(value='')
        tk.Label(body,textvariable=self.result,bg='white',fg='#166534',wraplength=600,justify='left',anchor='w').pack(fill='x',pady=(12,0))

        actions=tk.Frame(body,bg='white'); actions.pack(fill='x',pady=16)
        ttk.Button(actions,text='REGISTER & OPEN LOGIN',command=self.register_and_open).pack(side='left')
        ttk.Button(actions,text='OPEN UPS SERVICE MANAGER',command=self.open_app).pack(side='left',padx=10)

        note = ('The password is sent only to the UPS Service Manager signup endpoint and is not saved by this launcher. '
                'Tailscale authentication is handled by Tailscale itself.')
        tk.Label(body,text=note,bg='white',fg='#64748b',font=('Segoe UI',8),wraplength=620,justify='left').pack(anchor='w',pady=(4,0))

        self.check_tailscale(silent=True)

    def set_status(self, text, good=None):
        self.status.set(text)
        if good is True:
            self.status_label.configure(bg='#ecfdf5', fg='#166534')
        elif good is False:
            self.status_label.configure(bg='#fef2f2', fg='#991b1b')
        else:
            self.status_label.configure(bg='#f8fafc', fg='#374151')

    def check_tailscale(self, silent=False):
        self.ts_path = find_tailscale()
        if not self.ts_path:
            self.set_status('Tailscale is not installed on this Windows PC.', False)
            if not silent:
                if messagebox.askyesno('Tailscale required', 'Tailscale was not found. Try to install it with Windows Package Manager (winget)?'):
                    self.install_tailscale()
            return False
        code,out=run_cmd([self.ts_path,'status'])
        if code == 0:
            self.set_status('Tailscale is installed and running. You can continue.', True)
            self.connected=True
            return True
        self.set_status('Tailscale is installed but is not connected yet. Click Open Tailscale and sign in.', False)
        if not silent:
            self.open_tailscale()
        return False

    def install_tailscale(self):
        self.set_status('Installing Tailscale with Windows Package Manager...', None)
        def worker():
            code,out=run_cmd(['winget','install','--id','Tailscale.Tailscale','--exact','--scope','user','--accept-package-agreements','--accept-source-agreements'],timeout=180)
            self.root.after(0, lambda: self._install_done(code,out))
        threading.Thread(target=worker,daemon=True).start()

    def _install_done(self,code,out):
        if code==0:
            self.set_status('Tailscale installed. Opening Tailscale for sign-in...', True)
            self.ts_path=find_tailscale()
            self.open_tailscale()
        else:
            self.set_status('Tailscale installation failed. Please install Tailscale manually.', False)
            messagebox.showerror('Tailscale', 'Automatic installation did not complete. Please install Tailscale from the official Tailscale Windows installer, then click Check / Start Tailscale.')

    def open_tailscale(self):
        p=self.ts_path or find_tailscale()
        if p:
            try:
                subprocess.Popen([p], creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            except Exception:
                pass
        else:
            webbrowser.open('https://tailscale.com/download/windows')

    def open_app(self):
        webbrowser.open(SERVER_URL + '/')

    def register_and_open(self):
        email=self.email.get().strip(); user=self.username.get().strip(); pw=self.password.get(); cp=self.confirm.get()
        if not email or not user or not pw or not cp:
            messagebox.showwarning('Missing information','Please fill Email, Username, Password and Confirm Password.')
            return
        if pw != cp:
            messagebox.showwarning('Password mismatch','Password and Confirm Password do not match.')
            return
        if not self.check_tailscale(silent=True):
            messagebox.showwarning('Secure connection required','Please connect/sign in to Tailscale first, then register.')
            return
        self.result.set('Submitting registration request...')
        payload=json.dumps({'email':email,'username':user,'password':pw}).encode()
        req=urllib.request.Request(SERVER_URL+'/api/signup',data=payload,headers={'Content-Type':'application/json'},method='POST')
        def worker():
            try:
                with urllib.request.urlopen(req,timeout=15) as r:
                    data=json.loads(r.read().decode('utf-8','replace'))
                msg=data.get('message','Registration submitted successfully.')
                self.root.after(0,lambda:self._registered(msg))
            except urllib.error.HTTPError as e:
                try: detail=json.loads(e.read().decode()).get('error',str(e))
                except Exception: detail=str(e)
                self.root.after(0,lambda:self._registration_error(detail))
            except Exception as e:
                self.root.after(0,lambda:self._registration_error(str(e)))
        threading.Thread(target=worker,daemon=True).start()

    def _registered(self,msg):
        self.result.set(msg)
        messagebox.showinfo('Registration submitted', msg + '\n\nPlease wait for Admin approval. The application will now open the login page.')
        self.open_app()

    def _registration_error(self,msg):
        self.result.set('Registration failed: '+msg)
        messagebox.showerror('Registration failed',msg)


if __name__=='__main__':
    root=tk.Tk()
    App(root)
    root.mainloop()
