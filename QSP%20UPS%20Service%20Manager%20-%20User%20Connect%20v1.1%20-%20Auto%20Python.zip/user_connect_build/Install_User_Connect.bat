@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PYVER=3.11.9"
set "PYEXE=%LocalAppData%\Programs\Python\Python311\python.exe"
set "PYURL=https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
set "PYINSTALLER=%TEMP%\python-3.11.9-amd64.exe"

echo ================================================
echo QSP UPS Service Manager - User Connect Setup
echo ================================================
echo.

if exist "%PYEXE%" goto PY_OK
for /f "delims=" %%P in ('where python 2^>nul') do (
  "%%P" -c "import sys; raise SystemExit(0 if sys.version_info[:2]==(3,11) else 1)" >nul 2>&1
  if not errorlevel 1 set "PYEXE=%%P"& goto PY_OK
)

echo Python 3.11 is not installed. Downloading official Python 3.11.9 installer...
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-WebRequest -UseBasicParsing -Uri '%PYURL%' -OutFile '%PYINSTALLER%' } catch { exit 1 }"
if errorlevel 1 (
  echo.
  echo ERROR: Could not download Python from python.org.
  echo Please check your Internet connection and run this setup again.
  pause
  exit /b 1
)

echo Installing Python 3.11.9 silently for the current Windows user...
"%PYINSTALLER%" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0 Include_launcher=1
if errorlevel 1 (
  echo ERROR: Python installation failed.
  pause
  exit /b 1
)
del /q "%PYINSTALLER%" >nul 2>&1
if exist "%PYEXE%" goto PY_OK
set "PYEXE=%LocalAppData%\Programs\Python\Python311\python.exe"
if not exist "%PYEXE%" (
  echo ERROR: Python 3.11 was installed but could not be located.
  pause
  exit /b 1
)

:PY_OK
echo Python 3.11 ready.
echo Starting QSP UPS Service Manager - User Connect...
"%PYEXE%" "%~dp0QSP_UPS_User_Connect.py"
endlocal
